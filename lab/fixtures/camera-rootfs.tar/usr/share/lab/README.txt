These files exercise archive parsers. Component banners are fixtures, not installed executables.
